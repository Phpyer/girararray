<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\MatrizValidateRequest;

class MatrizController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        //VALIDACION
        $rules = [
           
            'dimension'     => 'required|numeric',
         
            ];
 
        $validator = \Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return [
                'errores'  => $validator->errors()->all()
            ];
        }

        //CAPTURA VALOR

        $dimension = $request->dimension;

        //GENERA ARRAY
        $array_base = $this->generateArray($dimension);
        $array_girar =$this->generateOutput($dimension,$array_base);
        
    
        
        return ["INPUT"=>$array_base,"OUTPUT"=>$array_girar];

    }

    public function generateArray($dimension){

        for($i=0; $i < $dimension ; $i++){

            for($j=0;$j<$dimension;$j++){
               $array_base[$i][$j]=rand(1,100);     
            }

        }

        return $array_base;

    }

    public function generateOutput($dimension,$array_base){

        $d=$dimension;

        for($i=0;$i<$dimension;$i++){
            
            $d =$d-1;   
            for($j=0;$j<$dimension;$j++){

                $array_girar[$i][$j] = $array_base[$j][$d];
            
            }
        }
        return $array_girar;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
